#include <Windows.h>
#include <CMath>
#pragma comment(lib, "winmm.lib") // WinMM library loader
#include <mmsystem.h>
